function t(t,e=300){let i;return(...o)=>{i&&clearTimeout(i),i=setTimeout((()=>{t.apply(this,o)}),e)}}export{t as d};
